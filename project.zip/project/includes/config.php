<?php 
define('HOST','localhost');
define('USER','root');
define('PASS','');
define('NAME','db_railway');

try
{
$dbh = new PDO("mysql:host=".HOST.";dbname=".NAME,USER,PASS,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
}
catch (PDOException $e)
{
exit("Error: " . $e->getMessage());
}
?>