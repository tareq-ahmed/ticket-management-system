<header>
  <div class="default-header">
    <div class="container">
      <div class="row">
        <div class="col-sm-3 col-md-2">
          <div class="logo"> <a href="index.php"><img src="" alt=""/></a> </div>
        </div>
        <div class="col-sm-9 col-md-10">
          <div class="header_info">
            <div class="header_widgets">
              <div class="circle_icon"> <a href="mailto:railmanager@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a> </div>
              <p class="uppercase_text">Support Email: </p>
              <a href="mailto:railmanager@gmail.com">railmanager@gmail.com</a> </div>
            <div class="header_widgets">
              <div class="circle_icon"> <a href="tel:+8801815147347"><i class="fa fa-phone" aria-hidden="true"></i> </a></div>
              <p class="uppercase_text">Call Us: </p>
              <a href="tel:+8801815147347">+8801815147347</a> 
              </div>
            <div class="header_widgets">
              <div class="circle_icon"> <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></div>
              <div class="circle_icon"> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></div>
              <div class="circle_icon"> <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></div>
              <div class="circle_icon"> <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></a></i></div>
            </div>
            </div>
   <?php   if(strlen($_SESSION['login'])==0)
	{	
?>
 <div class="login_btn"> <a href="#loginform" class="btn btn-xs uppercase" data-toggle="modal" data-dismiss="modal">Login or Register</a> </div>
<?php }
else{ 

echo "Welcome to railmanager!";
 } ?>
          
        </div>
      </div>
    </div>
  </div>
  
  <!-- Navigation -->
  <nav id="navigation_bar" class="navbar navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button id="menu_slide" data-target="#navigation" aria-expanded="false" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
      </div>
      <div class="header_wrap">
        <div class="user_login">
          <ul>
            <li class="dropdown"> <a href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user-circle" aria-hidden="true"></i> 
<?php 
$email=$_SESSION['login'];
$sql ="SELECT FullName FROM tblusers WHERE EmailId=:email ";
$query= $dbh -> prepare($sql);
$query-> bindParam(':email', $email, PDO::PARAM_STR);
$query-> execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
	{
	 echo htmlentities($result->FullName); }}?>
   <i class="fa fa-angle-down" aria-hidden="true"></i></a>
              <ul class="dropdown-menu">
           <?php if($_SESSION['login']){?>
            <li><a href="profile.php">Profile</a></li>
              <li><a href="update_password.php">Change Password</a></li>
            <li><a href="my_tickets.php">My Tickets</a></li>
            <li><a href="post_testimonials.php">Post a Testimonial</a></li>
          <li><a href="my_testimonials.php">My Testimonials</a></li>
            <li><a href="logout.php">Log Out</a></li>
            <?php } else { ?>
            <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">Profile</a></li>
              <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">Change Password</a></li>
            <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">My Bookings</a></li>
            <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">Post a Testimonial</a></li>
          <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">My Testimonials</a></li>
            <li><a href="#loginform"  data-toggle="modal" data-dismiss="modal">Log Out</a></li>
            <?php } ?>
          </ul>
            </li>
          </ul>
        </div>

        <div class="header_search">
          <div id="search_toggle"><i class="fa fa-search" aria-hidden="true"></i></div>
          <form action="search_result.php" method="post" id="header-search-form">
            <input type="text" placeholder="Search..." class="form-control" name="menu_search">
            <button type="submit" name="menu_search_btn"><i class="fa fa-search" aria-hidden="true"></i></button>
          </form>
        </div>

      </div>
      <div class="collapse navbar-collapse" id="navigation">
        <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li><a href="page.php?type=aboutus">About Us</a></li>
          <li><a href="buy_tickets.php">Buy Tickets</a>
          <li><a href="fare_query.php">Fare Query</a>
          <li><a href="#">Tracker</a>
          <li><a href="schedule.php">Schedule</a>
          <li><a href="#">News</a>
          <li><a href="#">Cancellation</a>
          <li><a href="page.php?type=faqs">FAQ</a>
          <li><a href="contact_us.php">Contact Us</a></li>

        </ul>
      </div>
    </div>
  </nav>
  <!-- Navigation end --> 
  
</header>