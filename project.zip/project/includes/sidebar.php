<div class="profile_nav">
          <ul>
            <li><a href="profile.php">Settings</a></li>
              <li><a href="update-password.php">Update Password</a></li>
            <li><a href="my-booking.php">My Bookings</a></li>
            <li><a href="post-testimonial.php">Write Testimonial</a></li>
               <li><a href="my-testimonials.php">My Testimonials</a></li>
            <li><a href="logout.php">Log Out</a></li>
          </ul>
        </div>
      </div>