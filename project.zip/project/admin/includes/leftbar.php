<nav class="ts-sidebar">
	<ul class="ts-sidebar-menu">
		<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		<li><a href="reg-users.php"><i class="fa fa-users"></i>View Users</a></li>
		<li><a href="manage-subscribers.php"><i class="fa fa-user"></i>Manage Users</a></li>

		<li><a href="#"><i class="fa fa-files-o"></i>Trains</a>
			<ul>
			<li><a href="<>create-brand.php">Add New Train</a></li>
			<li><a href="<>manage-brands.php">Manage Trains</a></li>
			</ul>
		</li>

		<li><a href="#"><i class="fa fa-sitemap"></i>Tickets</a>
			<ul>
			<li><a href="<>post-avehical.php">Add Tickets</a></li>
			<li><a href="<>manage-vehicles.php">Manage Tickets</a></li>
			</ul>
		</li>
		<li><a href="#"><i class="fa fa-sitemap"></i>Schedule</a>
			<ul>
			<li><a href="<>post-avehical.php">Add Schedule</a></li>
			<li><a href="<>manage-vehicles.php">Manage Schedule</a></li>
			</ul>
		</li>
		<li><a href="manage-bookings.php"><i class="fa fa-book"></i> Manage Bookings</a></li>

		<li><a href="testimonials.php"><i class="fa fa-table"></i> Manage Testimonials</a></li>
		<li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i> Manage Messages</a></li>
		<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Site Info</a></li>
		<li><a href="update-contactinfo.php"><i class="fa fa-info"></i> Change Contact Info</a></li>
	</ul>
</nav>